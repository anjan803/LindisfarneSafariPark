<?php
session_start();
	$_SESSION['user']=$user;
	include_once 'connect.php';
	$fname=$_POST['firstname'];
	$lname=$_POST['lastname'];
	$user=$_POST['user'];
	$pass=$_POST['pass1'];
	$add=$_POST['address'];
    $code=$_POST['code'];
    $gender=$_POST['gender'];
	$contact=$_POST['contact'];

	
	$sql = mysqli_query($connect,"SELECT cust_id FROM customer WHERE user='$user'") ;


if (mysqli_num_rows($sql) < 1) {
   
	$sql_query="insert into customer(fname,lname,user,pass,address,code,gender,contact)values('$fname','$lname',
	'$user','$pass','$add','$code','$gender','$contact')";
	
	mysqli_query($connect,$sql_query) or die ('Error');

header("location:login.php");
}
else{
	echo "Username Already exists";
}
?>