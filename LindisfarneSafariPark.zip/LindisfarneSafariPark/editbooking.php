<html>
<head>
<title>Edit Booking</title>
<style type="text/css">
body {
margin:0 auto;
background-image:url("qq.jpg");
background-repeat:no-repeat;
background-size:100%;
}

</style>
<style>
.transparent{
color:white;
width: 500px;
height:350px;
 background-color: rgba(24,77,88,0.7);
 
}
.head{

width: 100%;
height:40px;
 background-color:rgba(22, 88, 49,1.7);
}


</style>
<?php
include("nav.php");
session_start();
	$id=$_SESSION["id"];
	include_once 'connect.php';
if(!isset($_SESSION["id"])){
header("Location:login.php");
}
else
	$ts=$_GET['ts'];
{?>
</head>
<body>

<center>
<div class="transparent">  
   <div class="head"> <h1>Booking ticket</h1></div>
<h1> Edit booking </h1>
<form method="POST" action="updatebooking.php">
<table>

   <?php
	$sql = mysqli_query($connect,"SELECT * FROM ticketservice WHERE ts_id='$ts'") ;


while ($det = mysqli_fetch_array($sql)){
	$t_id=$det["ticket_id"]; 
	$day=explode(",",$det['day_id']);
	$time=explode(",",$det['s_time']);
	$ser=$det["service_id"];
	$s = mysqli_query($connect,"SELECT ticketName FROM ticket WHERE ticket_id='$t_id'");
	while ($get = mysqli_fetch_array($s)){
		$name=$get["ticketName"];
	

   echo "<header>ticket Name:".$name."</header>";
   ?><input type="text" name="ticket" value="<?php echo $name; ?>" hidden/>
   <input type="text" name="ts" value="<?php echo $ts; ?>" hidden/>
   <?php
}
}
?>
<tr><td>Select day(s)</td></tr><tr><td>
  <input type="checkbox" name="day[]" value="5" <?php if(in_array("5",$day)) echo 'checked="checked"'; ?>/>Sunday</td><td>
  <input type="checkbox" name="day[]" value="6" <?php if(in_array("6",$day)) echo 'checked="checked"'; ?>/>Monday</td><td>
<input type="checkbox" name="day[]" value="7" <?php if(in_array("7",$day)) echo 'checked="checked"'; ?>/>Tuesday</td></tr><tr><td> 
<input type="checkbox" name="day[]" value="8" <?php if(in_array("8",$day)) echo 'checked="checked"'; ?>/>Wednesday</td><td>
<input type="checkbox" name="day[]" value="9" <?php if(in_array("9",$day)) echo 'checked="checked"'; ?>/>Thursday</td><td>
<input type="checkbox" name="day[]" value="10" <?php if(in_array("10",$day)) echo 'checked="checked"'; ?>/>Friday</td><td>
<input type="checkbox" name="day[]" value="11" <?php if(in_array("11",$day)) echo 'checked="checked"'; ?>/>Saturday</td></tr>
  </select></td></tr>

  <tr><td>Select Service</td> <td><select id="service" name="service">

  <option value="1">Adults</option>
  <option value="2">Children</option>
  <option value="3"> Old Age Pensioners</option>
  <option value="4">Families</option>


  </select>

  <tr><td>Select time</td></tr><tr><td>
  <input type="checkbox" name="d[]" value="10:00 AM" <?php if(in_array("10:00 AM",$time)) echo 'checked="checked"'; ?> />10:00 AM</td><td>
  <input type="checkbox" name="d[]" value="11:00 AM" <?php if(in_array("11:00 AM",$time)) echo 'checked="checked"'; ?> />11:00 AM</td><td>
<input type="checkbox" name="d[]" value="12:00 AM" <?php if(in_array("12:00 AM",$time)) echo 'checked="checked"'; ?> />12:00 AM</td></tr><tr><td> 
<input type="checkbox" name="d[]" value="01:00 PM" <?php if(in_array("01:00 PM",$time)) echo 'checked="checked"'; ?> />01:00 PM</td><td>
<input type="checkbox" name="d[]" value="02:00 PM" <?php if(in_array("02:00 PM",$time)) echo 'checked="checked"'; ?> />02:00 PM</td><td>
<input type="checkbox" name="d[]" value="03:00 PM" <?php if(in_array("03:00 PM",$time)) echo 'checked="checked"'; ?> />03:00 PM</td><td>
<input type="checkbox" name="d[]" value="04:00 PM" <?php if(in_array("04:00 PM",$time)) echo 'checked="checked"'; ?> />04:00 PM</td></tr>
  <tr><td><input type="submit" value="Update" name="sub"></td>
  
  </table>
  </form>
  </div>
  </center>
  </body>
  </body>
  </html>
<?php }?>