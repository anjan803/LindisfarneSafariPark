<?php
	include_once 'connect.php';
	session_start();
	$id= $_SESSION["id"];
	$pet=$_POST['addticket'];
	
	
	$sql = mysqli_query($connect,"SELECT ticket_id FROM ticket WHERE ticketName='$pet'") ;


if (mysqli_num_rows($sql) < 1) {
   
	$sql_query="insert into ticket(ticketName)values('$pet')";
	mysqli_query($connect,$sql_query) or die ('Error');
}
$q = mysqli_query($connect,"SELECT ticket_id FROM ticket WHERE ticketName='$pet'") ;
	while ($det = mysqli_fetch_array($q)){
		$pid=$det['ticket_id'];
		$s="insert into custticket(cust_id,ticket_id)values('$id','$pid')";
	
	mysqli_query($connect,$s) or die ('Error');
		}
header("location:Ticketadding.php");
?>