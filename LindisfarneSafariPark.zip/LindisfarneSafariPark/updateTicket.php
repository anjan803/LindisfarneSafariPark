<!doctype html>
<?php
session_start();
if(!isset($_SESSION["id"])){
header("Location:login.php");
}
else
{
$id=$_SESSION["id"];
include ("connect.php");
?>

<?php
}?>
<html>
<head>
<title>Update Ticket</title>
<style>
.transparent{
color:white;
width: 300px;
height:220px;
 background-color: rgba(75,34,44,0.7);
 
}
.head{

width: 100%;
height:40px;
 background-color:rgba(36, 43, 49,0.7);
}
body {
margin:0 auto;
background-image:url("bb.jpg");
background-repeat:no-repeat;
background-size:100%;
}
</style>
<?php
include ("nav.php");
?>
</head>
<body>
<center>
<div class="transparent" id="div">
<div class="head"> <h3> Add Ticket</h3></div>
<form action="upTicket.php" method="POST">
<table>
   	<tr><td>Select Ticket</td> <td><select id="ticket" name="ticket" required>
   <?php
	$sql = mysqli_query($connect,"SELECT ticket_id FROM custticket WHERE cust_id='$id'") ;

while ($det = mysqli_fetch_array($sql)){
	$p_id=$det["ticket_id"];
	$s = mysqli_query($connect,"SELECT ticketName FROM ticket WHERE ticket_id='$p_id'");
	while ($get = mysqli_fetch_array($s)){
		$name=$get["ticketName"];
	?>
  <option value="<?php echo $p_id; ?>" required><?php echo $name; ?> </option><?php
}
}
?>
<tr><td>Ticket Name/NO</td> </tr><tr><td> <input type="text" name="pn"></td></tr>
<tr><td><input type="submit" value="Edit" name="edit" /></td><td><input type="submit" value="Remove" name="remove" /></td></tr>
</table>
</form>
</div>
</center>
</body>
</html>
