<head>
<title>Booking Ticket</title>
<style type="text/css">
body {
margin:0 auto;
background-image:url("GG.jpg");
background-repeat:no-repeat;
background-size:100%;
}

</style>
<style>
.transparent{
color:white;
width: 500px;
height:300px;
 background-color: rgba(24,77,88,0.7);
 
}
.head{

width: 100%;
height:40px;
 background-color:rgba(22, 88, 49,1.7);
}


</style>
</head>
<?php
include("nav.php");
session_start();
	$id=$_SESSION["id"];
	include_once 'connect.php';
if(!isset($_SESSION["id"])){
header("Location:login.php");
}
else
{
	?>
    <body>


<center>	
<div class="transparent">  
   <div class="head"> <h1>Booking</h1></div>
   <form action="Bookingsql.php" method="POST">
 
<?php
   }?>
      <table>
   	<tr><td>Select Ticket</td> <td><select id="ticket" name="ticket" required>
   <?php
	$sql = mysqli_query($connect,"SELECT ticket_id FROM custticket WHERE cust_id='$id'") ;


while ($det = mysqli_fetch_array($sql)){
	$t_id=$det["ticket_id"]; 
	$s = mysqli_query($connect,"SELECT ticketName FROM ticket WHERE ticket_id='$t_id'");
	while ($get = mysqli_fetch_array($s)){
		$name=$get["ticketName"];
	?>

  <option value="<?php echo $t_id; ?>" required><?php echo $name; ?> </option><?php
}
}
?>
<tr><td>Select day(s)</td></tr><tr><td>
  <input type="checkbox" name="day[]" value="Sunday">Sunday</td><td>
  <input type="checkbox" name="day[]" value="Monday">Monday</td><td>
<input type="checkbox" name="day[]" value="Tuesday">Tuesday</td></tr><tr><td> 
<input type="checkbox" name="day[]" value="Wednesday">Wednesday</td><td>
<input type="checkbox" name="day[]" value="Thursday">Thursday</td><td>
<input type="checkbox" name="day[]" value="Friday">Friday</td><td>
<input type="checkbox" name="day[]" value="Saturday">Saturday</td></tr>



       <tr><td>Select Service</td> <td><select id="service" name="service" required>
	<option value=""></option>
  <option value="1">Adults</option>
  <option value="2">Children</option>
  <option value="3">Old Age Pensioners</option>
  <option value="4">Families</option>
  </select>

  <tr><td>Select time</td></tr><tr><td>
  <input type="checkbox" name="d[]" value="10:00 AM">10:00 AM</td><td>
  <input type="checkbox" name="d[]" value="11:00 AM">11:00 AM</td><td>
<input type="checkbox" name="d[]" value="12:00 AM">12:00 AM</td></tr><tr><td> 
<input type="checkbox" name="d[]" value="01:00 PM">01:00 PM</td><td>
<input type="checkbox" name="d[]" value="02:00 PM">02:00 PM</td><td>
<input type="checkbox" name="d[]" value="03:00 PM">03:00 PM</td><td>
<input type="checkbox" name="d[]" value="04:00 PM">04:00 PM</td></tr>
<tr><td><input type="submit" name="save" value="Save"></td><td><input type="reset" value="Reset"></td></tr>
	   </table>
    </form>

 
 </center>
 <hr>
 <header>Service Detail</header>
<p>Adults ticket price is £50.</p>
<p> Childrens ticket price is £25</p>
<p> Old Age Pensioners ticket price is £25</p>
<p> Families ticket price is £100</p>
</body>
</html>
	