<?php
session_start();
if(!isset($_SESSION["id"])){
header("Location:login.php");
}
else
{
	$id=$_SESSION['id'];
	include_once 'connect.php';
	$ticket=$_POST['ticket'];
	$cd=count($_POST['day']);
	$service=$_POST['service'];
	$time=$_POST['d'];
	$session=count($_POST['d']);
	   $a = mysqli_query($connect,"SELECT cost FROM service WHERE service_id='$id'") ;
   while ($det = mysqli_fetch_array($a)){
	$d=$det["service"];
   }

if($service==4 ){
	$cost=100;
}
else if($service==1) {
	$cost=50;
}
else if ($service==3){
	$cost=25;
}
else if ($service==2){
	$cost=25;
}
   if($d<=10){
	$t=$session*cost;
	}
	else{
		$ds=$d-10;
		$dt=$ds*0.50;
		$total=($session*$cost)+$dt;
	}

foreach($_POST['day'] as $selected){
$day = mysqli_query($connect,"SELECT day_id FROM day WHERE day='$selected'") ;
while ($get = mysqli_fetch_array($day)){
	$d_id=$get["day_id"];
	foreach($_POST['d'] as $t){	
$q = "Insert into dt(ticket_id,day_id,s_time) value('$ticket','$d_id','$t')";
$query = "Insert into ticketservice(ticket_id,day_id,service_id,s_time,length,price) value('$ticket','$d_id','$service','$t','$session','$total')";
mysqli_query($connect,$query) or die ('Error');
mysqli_query($connect,$q) or die ('Error');
header("location:Booking.php");
}
}
}
}