<!doctype html>
<html>
<head>
<title>register</title>
<style type="text/css">
body {

</style>
<style>
.transparent2{
color:white;
width: 300px;
height:400px;
 background-color: rgba(24,77,88,0.7);
 
}
.head{

width: 100%;
height:40px;
 background-color:rgba(22, 88, 49,1.7);
}


</style>
</head>
    <body>


<center>	
<div class="transparent2">  
   <div class="head"> <h1>registration</h1></div>
   <form action="reg.php" method="POST">
   <table>
        <tr><td>First Name:</td> <td><input type="text" name="firstname" required></td></tr>
        <tr><td>Last Name:</td> <td><input type="text" name="lastname" required></td></tr>
		<tr><td>Username:</td> <td><input type="text" name="user" required></td></tr>
		<tr><td>Password:</td> <td><input type="password" name="pass1" id="pass1" required></td></tr>
		<tr><td>Confirm Password:</td> <td><input type="password" name="pass2"  id="pass2" onkeyup="checkPass(); return false;" required></td></tr>
       <tr><td>Postal address:</td> <td><input type="text" name="address" required></td></tr>
       <tr><td>Postal Code:</td> <td><input type="text" name="code" required></td></tr>
       <tr><td>Gender:</td> <td><input type="text" name="gender" required></td></tr>
       <tr><td>Contact no:</td> <td><input type="text" name="contact" required></td></tr>
       <tr> <td><input type="submit" value="Register" name="submit" /></td></tr>
	   <tr><td><a href="login.php">Already register??</a></td></tr>
	   </table>
    </form>
<script language="javascript" type="text/javascript"> 
function checkPass()
{
   
    var pass1 = document.getElementById('pass1');
    var pass2 = document.getElementById('pass2');
  


    var goodColor = "#66cc66";
    var badColor = "#ff6666";
   
    if(pass1.value == pass2.value){
       
        pass2.style.backgroundColor = goodColor;
        message.style.color = goodColor;
     
    }else{
        
        pass2.style.backgroundColor = badColor;
        message.style.color = badColor;
        
    }
}  
</script>
	</div>
    </center>	
    </body>
    </html>
