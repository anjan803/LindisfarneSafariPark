<?php


include_once ("../../PHPMailer-master/PHPMailerAutoload.php");
include_once ("../connectin.php");
    $ticket_id = $_GET['id'];
    $mailto = $_GET['email'];

    $sql = "select * from ticketName where ticket_id = $ticket_id";
    $res = querySelect($sql);
    $row = mysqli_fetch_array($res);

    $mailSub = "Booking Accepted";
    $mailMsg = "Dear Sir/Madam,\n As you requested, we have accepted your booking. Your ticket discription is:\n
                Title: ".$row[3]."\n Ticket Type: ".$row[4]."\n Price: ".$row[5]."\n Thank you";



    $mail = new PHPMailer();
    $mail ->IsSmtp();
    $mail ->SMTPDebug = 0;
    $mail ->SMTPAuth = true;
    $mail ->SMTPSecure = 'ssl';
    $mail ->Host = "smtp.gmail.com";
    $mail ->Port = 465; // or 587;
    $mail ->IsHTML(true);
    $mail ->Username = "arjunrai12@gmail.com";
    $mail ->Password = "Arjun12";
    $mail ->SetFrom("arjunrai12@gmail.com");
    $mail ->Subject = $mailSub;
    $mail ->Body = $mailMsg;
    $mail ->AddAddress($mailto);

   if(!$mail->Send()) {
       echo "Mail Not Sent";
   }
   else {
       ?>
       <script>
           alert("Email has been send");
           window.location.href = '../home.php';
       </script>
       <?php
   }









