<html>
<head>
<meta charset="UTF-8">
<title>nav</title>
<link rel="stylesheet" href="style.css" type="text/css" />

</head>
<body>

<div style="position:fixed; width:100%">
<ul>
<li ><img src="pet.jpg" width="37%" height="7%"></li>

    <li style="float:right" class="dropdown">
    <a href="#" class="dropbtn">customer</a>
    <div class="dropdown-content">
      <a href="login.php">login</a>
      <a href="register.php">register</a>
    </div>
  </li>
  
<li style="float:right"><a class="" href="home1.php">Home</a></li>
 </ul>



</div>




</body>
</html>
