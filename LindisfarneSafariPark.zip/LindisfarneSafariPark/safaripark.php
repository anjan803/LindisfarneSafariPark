<?php

$conn = mysqli_connect("localhost","root","") or die("Unable to connect");
$conn->query("create database if not exists safaripark");
mysqli_select_db($conn,'safaripark');
$conn->query("
CREATE TABLE IF NOT EXISTS `customer` (
`cust_id` int(11) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `user` varchar(20) NOT NULL,
  `pass` varchar(20) NOT NULL,
  `address` varchar(100) NOT NULL,
  `code` varchar(250) NOT NULL,
  `gender` varchar(250) NOT NULL,
  `contact` int(25) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;");



$conn->query("INSERT INTO `customer` (`cust_id`, `fname`, `lname`, `user`, `pass`, `address`, `code`, `gender`, `contact`) VALUES
(11, 'Anjan', 'Shrestha', 'Anjan', 'anjan', 'ktm', '12gh', 'male', 98435001);");





$conn->query("
CREATE TABLE IF NOT EXISTS `custticket` (
`ct_id` int(11) NOT NULL,
  `cust_id` int(11) NOT NULL,
  `ticket_id` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;");



$conn->query("INSERT INTO `custticket` (`ct_id`, `cust_id`, `ticket_id`) VALUES
(1, 5, 26),
(2, 5, 27),
(3, 5, 28),
(4, 5, 29),
(5, 5, 10),
(6, 5, 10),
(7, 5, 10),
(8, 5, 10),
(9, 5, 10),
(10, 5, 10),
(12, 11, 31),
(13, 11, 32),
(14, 11, 33),
(15, 11, 34),
(16, 11, 35),
(17, 11, 36);");





$conn->query("
CREATE TABLE IF NOT EXISTS `day` (
`day_id` int(11) NOT NULL,
  `day` varchar(30) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;");


$conn->query("
INSERT INTO `day` (`day_id`, `day`) VALUES
(5, 'Sunday'),
(6, 'Monday'),
(7, 'Tuesday'),
(8, 'Wednesday'),
(9, 'Thursday'),
(10, 'Friday'),
(11, 'Saturday');
");


$conn->query("
CREATE TABLE IF NOT EXISTS `dt` (
`dt_id` int(11) NOT NULL,
  `ticket_id` int(11) NOT NULL,
  `day_id` int(11) NOT NULL,
  `s_time` varchar(20) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=76 DEFAULT CHARSET=latin1;");



$conn->query("INSERT INTO `dt` (`dt_id`, `ticket_id`, `day_id`, `s_time`) VALUES
(1, 1, 6, '11:00 AM'),
(2, 1, 6, '02:00 PM'),
(3, 1, 9, '11:00 AM'),
(4, 1, 9, '02:00 PM'),
(5, 2, 6, '11:00 AM'),
(6, 2, 7, '11:00 AM'),
(7, 2, 8, '11:00 AM'),
(8, 2, 5, '10:00 AM'),
(9, 2, 5, '01:00 PM'),
(10, 2, 5, '04:00 PM'),
(11, 2, 9, '10:00 AM'),
(12, 2, 9, '01:00 PM'),
(13, 2, 9, '04:00 PM'),
(14, 9, 6, '01:00 PM'),
(15, 9, 6, '03:00 PM'),
(16, 9, 11, '01:00 PM'),
(17, 9, 11, '03:00 PM'),
(19, 9, 5, '12:00 AM'),
(20, 9, 5, '04:00 PM'),
(21, 9, 6, '10:00 AM'),
(22, 9, 6, '12:00 AM'),
(23, 9, 6, '04:00 PM'),
(24, 9, 7, '10:00 AM'),
(25, 9, 7, '12:00 AM'),
(26, 9, 7, '04:00 PM'),
(27, 9, 8, '10:00 AM'),
(28, 9, 8, '12:00 AM'),
(29, 9, 8, '04:00 PM'),
(30, 9, 9, '10:00 AM'),
(31, 9, 9, '12:00 AM'),
(32, 9, 9, '04:00 PM'),
(33, 9, 10, '10:00 AM'),
(34, 9, 10, '12:00 AM'),
(35, 9, 10, '04:00 PM'),
(36, 8, 6, '10:00 AM'),
(37, 8, 8, '10:00 AM'),
(38, 2, 6, '10:00 AM'),
(39, 2, 6, '03:00 PM'),
(40, 2, 10, '10:00 AM'),
(41, 2, 10, '03:00 PM'),
(42, 8, 5, '10:00 AM'),
(43, 12, 5, '10:00 AM'),
(44, 13, 5, '11:00 AM'),
(45, 0, 5, '10:00 AM'),
(46, 0, 5, '10:00 AM'),
(47, 0, 5, '11:00 AM'),
(48, 0, 6, '11:00 AM'),
(49, 0, 5, '11:00 AM'),
(50, 0, 6, '11:00 AM'),
(51, 23, 6, '11:00 AM'),
(52, 25, 5, '10:00 AM'),
(53, 25, 5, '11:00 AM'),
(54, 23, 5, '10:00 AM'),
(55, 23, 5, '10:00 AM'),
(56, 26, 5, '11:00 AM'),
(57, 26, 5, '10:00 AM'),
(58, 26, 6, '10:00 AM'),
(59, 27, 6, '10:00 AM'),
(60, 28, 5, '10:00 AM'),
(61, 29, 5, '10:00 AM'),
(62, 27, 5, '11:00 AM'),
(63, 26, 5, '11:00 AM'),
(64, 26, 5, '10:00 AM'),
(65, 26, 6, '10:00 AM'),
(66, 31, 5, '11:00 AM'),
(67, 31, 5, '10:00 AM'),
(68, 31, 9, '11:00 AM'),
(69, 31, 9, '10:00 AM'),
(70, 32, 5, '10:00 AM'),
(71, 33, 5, '11:00 AM'),
(72, 33, 9, '01:00 PM'),
(73, 34, 5, '10:00 AM'),
(74, 31, 5, '11:00 AM'),
(75, 36, 5, '11:00 AM');");


$conn->query("
CREATE TABLE IF NOT EXISTS `service` (
  `service_id` int(11) NOT NULL,
  `service` varchar(30) NOT NULL,
  `cost` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;");



$conn->query("INSERT INTO `service` (`service_id`, `service`, `cost`) VALUES
(1, 'Adults', 50),
(2, 'Children', 25),
(3, 'Old Age Pensioners', 25),
(4, 'Families', 100);");


$conn->query("
CREATE TABLE IF NOT EXISTS `ticket` (
`ticket_id` int(11) NOT NULL,
  `ticketName` varchar(30) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=latin1;");



$conn->query("INSERT INTO `ticket` (`ticket_id`, `ticketName`) VALUES
(31, '123'),
(32, '321'),
(33, '43'),
(34, '0'),
(35, 'op'),
(36, '2');");


$conn->query("
CREATE TABLE IF NOT EXISTS `ticketservice` (
`ts_id` int(11) NOT NULL,
  `ticket_id` int(11) NOT NULL,
  `day_id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  `s_time` varchar(30) NOT NULL,
  `length` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `vip_id` int(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=93 DEFAULT CHARSET=latin1;");



$conn->query("INSERT INTO `ticketservice` (`ts_id`, `ticket_id`, `day_id`, `service_id`, `s_time`, `length`, `price`, `vip_id`) VALUES
(21, 1, 9, 1, '11:00 AM', 2, 7, 0),
(22, 1, 9, 2, '02:00 PM', 2, 7, 0),
(23, 2, 6, 3, '11:00 AM', 1, 13, 2),
(24, 2, 7, 3, '11:00 AM', 1, 13, 3),
(25, 2, 8, 3, '11:00 AM', 1, 13, 3),
(26, 2, 5, 2, '10:00 AM', 3, 14, 2),
(27, 2, 5, 2, '01:00 PM', 3, 14, 2),
(28, 2, 5, 2, '04:00 PM', 3, 14, 1),
(29, 2, 9, 2, '10:00 AM', 3, 14, 2),
(30, 2, 9, 2, '01:00 PM', 3, 14, 1),
(31, 2, 9, 2, '04:00 PM', 3, 14, 3),
(37, 9, 5, 2, '12:00 AM', 3, 12, 2),
(38, 9, 5, 2, '04:00 PM', 3, 12, 3),
(39, 9, 6, 2, '10:00 AM', 3, 12, 3),
(40, 9, 6, 2, '12:00 AM', 3, 12, 2),
(41, 9, 6, 2, '04:00 PM', 3, 12, 3),
(42, 9, 7, 2, '10:00 AM', 3, 12, 2),
(43, 9, 7, 2, '12:00 AM', 3, 12, 1),
(49, 9, 9, 2, '12:00 AM', 3, 12, 3),
(50, 9, 9, 2, '04:00 PM', 3, 12, 3),
(52, 9, 10, 2, '12:00 AM', 3, 12, 1),
(53, 9, 10, 2, '04:00 PM', 3, 12, 2),
(54, 8, 6, 3, '10:00 AM', 1, 11, 1),
(56, 2, 6, 1, '10:00 AM', 2, 7, 1),
(57, 2, 6, 1, '03:00 PM', 2, 7, 2),
(58, 2, 10, 1, '10:00 AM', 2, 7, 0),
(59, 2, 10, 1, '03:00 PM', 2, 7, 0),
(60, 8, 5, 2, '10:00 AM', 1, 6, 0),
(63, 0, 5, 2, '10:00 AM', 1, 4, 0),
(64, 0, 5, 1, '10:00 AM', 1, 0, 0),
(65, 0, 5, 1, '11:00 AM', 1, 0, 0),
(66, 0, 6, 1, '11:00 AM', 1, 0, 0),
(67, 0, 5, 2, '11:00 AM', 1, 0, 0),
(68, 0, 6, 2, '11:00 AM', 1, 0, 0),
(69, 25, 5, 1, '10:00 AM', 1, 0, 0),
(70, 25, 5, 1, '11:00 AM', 1, 0, 1),
(71, 23, 5, 1, '10:00 AM', 1, 0, 0),
(72, 23, 5, 2, '10:00 AM', 1, 0, 0),
(73, 26, 5, 1, '11:00 AM', 1, 0, 0),
(74, 26, 5, 2, '10:00 AM', 1, 0, 0),
(75, 26, 6, 1, '10:00 AM', 1, 0, 0),
(76, 27, 6, 0, '10:00 AM', 1, 0, 0),
(77, 28, 5, 0, '10:00 AM', 1, 0, 0),
(78, 29, 5, 4, '10:00 AM', 1, 0, 0),
(79, 27, 5, 1, '11:00 AM', 1, 0, 0),
(80, 26, 5, 3, '11:00 AM', 1, 0, 0),
(81, 26, 5, 1, '10:00 AM', 1, 0, 0),
(82, 26, 6, 2, '10:00 AM', 1, 0, 0),
(83, 31, 5, 4, '11:00 AM', 1, 0, 0),
(84, 31, 5, 1, '10:00 AM', 1, 0, 0),
(85, 31, 9, 4, '11:00 AM', 1, 0, 0),
(86, 31, 9, 1, '10:00 AM', 1, 0, 0),
(87, 32, 5, 1, '10:00 AM', 1, 0, 0),
(88, 33, 5, 2, '11:00 AM', 1, 0, 0),
(89, 33, 9, 4, '01:00 PM', 1, 0, 0),
(90, 34, 5, 2, '10:00 AM', 1, 0, 1),
(91, 31, 5, 2, '11:00 AM', 1, 0, 0),
(92, 36, 5, 2, '11:00 AM', 1, 0, 0);");


$conn->query("CREATE TABLE IF NOT EXISTS `vip` (
`vip_id` int(11) NOT NULL,
  `vip` varchar(250) NOT NULL,
  `cost` int(13) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;");



$conn->query("INSERT INTO `vip` (`vip_id`, `vip`, `cost`) VALUES
(1, 'zoo keeper', 100),
(2, 'Off Road Experience', 200),
(3, ' Feed the Elephants', 300);");



$conn->query("
ALTER TABLE `customer`
 ADD PRIMARY KEY (`cust_id`);");



$conn->query("
ALTER TABLE `custticket`
 ADD PRIMARY KEY (`ct_id`);");



$conn->query("
ALTER TABLE `day`
 ADD PRIMARY KEY (`day_id`);");



$conn->query("
ALTER TABLE `dt`
 ADD PRIMARY KEY (`dt_id`);");

 
$conn->query("
ALTER TABLE `service`
 ADD PRIMARY KEY (`service_id`);");



$conn->query("
ALTER TABLE `ticket`
 ADD PRIMARY KEY (`ticket_id`);");



$conn->query("
ALTER TABLE `ticketservice`
 ADD PRIMARY KEY (`ts_id`), ADD KEY `type_id` (`vip_id`);");



$conn->query("
ALTER TABLE `vip`
 ADD PRIMARY KEY (`vip_id`);");



 
$conn->query("
ALTER TABLE `customer`
MODIFY `cust_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;");

 
$conn->query("
ALTER TABLE `custticket`
MODIFY `ct_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=18;");


$conn->query("
ALTER TABLE `day`
MODIFY `day_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;");


$conn->query("
ALTER TABLE `dt`
MODIFY `dt_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=76;");


$conn->query("
ALTER TABLE `ticket`
MODIFY `ticket_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=37;");



$conn->query("
ALTER TABLE `ticketservice`
MODIFY `ts_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=93;");


 
$conn->query("
ALTER TABLE `vip`
MODIFY `vip_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;");

 
$conn->query("
ALTER TABLE `vip`
ADD CONSTRAINT `vip_ibfk_1` FOREIGN KEY (`vip_id`) REFERENCES `service` (`service_id`);");


?>