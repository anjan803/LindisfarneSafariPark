<?php 
session_start();
unset($_SESSION['id']);
unset($_SESSION['user']);
unset($_SESSION['fname']);
header("location:login.php");
?>