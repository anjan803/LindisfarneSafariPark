
<?php
include "nav.php";

?>
<html>
<head>
<meta charset="UTF-8">
<title>home1</title>

<style type="text/css">
body {
margin:0 auto;
background-image:url("pet5.jpg");
background-repeat:no-repeat;
background-size:100%;
}

</style>
</head>

</body>
</html>
