	<?php
session_start();
if(!isset($_SESSION["id"])){
 header("Location: login.php");
}
else
{
?>
<?php
}
?>
<?php
include ("connect.php");
$id = $_SESSION["id"];
$pid = $_POST['ticket'];
$pn = $_POST['pn'];
if(isset($_POST['edit'])){
$query = mysqli_query($connect,"UPDATE ticket SET ticketName='$pn' WHERE ticket_id = '$pid'");

if($query){
	header("Location: updateTicket.php?msg=Successfully Update");
}else{
	header ("Location: updateTicket.php?msg=Error");
}
}
else if(isset($_POST['remove'])){
	$query = mysqli_query($connect,"Delete from ticket WHERE ticket_id = '$pid'");
	$q = mysqli_query($connect,"DELETE FROM custticket WHERE ticket_id = '$pid'");
if($query && $q){
	header("Location: updateTicket.php?msg=Successfully Update");
}else{
	header ("Location: updateTicket.php?msg=Error");
}
}
?>