<?php
include("nav.php");
session_start();
	$id=$_SESSION["id"];
	include_once 'connect.php';
if(!isset($_SESSION["id"])){
header("Location:login.php");
}
else
{?>
<html>
<head>
<body>
</center>
</table>
<form method="POST" action="">
Select Ticket <br> <td><select id="ticket" name="ticket" required>
<?php
$tot=0;
$sql = mysqli_query($connect,"SELECT ticket_id FROM custticket WHERE cust_id='$id'") ;


while ($det = mysqli_fetch_array($sql)){
	$t_id=$det["ticket_id"]; 
	$s = mysqli_query($connect,"SELECT ticketName FROM ticket WHERE ticket_id='$t_id'");
	while ($get = mysqli_fetch_array($s)){
		$name=$get["ticketName"];
		?> <option value="<?php echo $t_id; ?>" name="t_id" required><?php echo $name; ?> </option> <?php
	}
}
}?>
	<input type="submit" value="Search Cost" name="cst">
</center>
</table>
</form>
<?php
if(isset($_POST['cst'])){
	
	$t_id=$_POST['ticket'];
$b = mysqli_query($connect,"SELECT * FROM ticketservice WHERE ticket_id='$t_id'");
	while ($t = mysqli_fetch_array($b)){
		$pr=$t["price"];
		$ser=$t["service_id"];
		$day_id=$t["day_id"];
		$st=$t['s_time'];
		$tot=$tot+$pr;
		$c = mysqli_query($connect,"SELECT * FROM day WHERE day_id='$day_id'");
		while ($tn = mysqli_fetch_array($c)){
			$dE=$tn["day"];
		}
			echo "<tr><td>{$dE}</td></tr><br>";
			echo "<tr><td>{$st}</td></tr><br>";
			$d = mysqli_query($connect,"SELECT * FROM service WHERE service_id='$ser'");
		while ($tnt = mysqli_fetch_array($d)){
			$dt=$tnt["service"];
			echo "<tr><td>{$dt} cost=";
			echo "{$pr}</td></tr><br><hr>";
		}
		}
		echo"Total cost for the ticket £{$tot}";
		
	}
	

