<!doctype html>
<html>
<head>
<title>Login</title>

<style type="text/css">
body {

</style>
<style>
.transparent{
color:white;
width: 300px;
height:250px;
 background-color: rgba(24,77,88,0.7);
 
}
.head{

width: 100%;
height:40px;
 background-color:rgba(22, 88, 49,1.7);
}


</style>
</head>
<body>

<center>
<div class="transparent">
<div class="head"> <h3> Login Form</h3></div>

<form action="" method="POST">
<table>
<tr><td>User Name:</td> </tr><tr><td> <input type="text" name="user"required></td></tr>
<tr><td>Password:</td></tr><tr><td> <input type="password" name="pass" required><br/>	<br/></td></tr>

<tr><td><label><input type="checkbox" class="link" name="autologin" value="1"> Remember me</label></td></tr>
<tr><td><input type="submit" value="Login" name="submit" /></td></tr>
<tr><td><a href="register.php" style="color:black">Not register yet??</a></td></tr>
</form>
</div>
</center>
</body>
</html>
<?php
include("connect.php");
if(!empty($_POST['user']) && !empty($_POST['pass'])) {
	$user=$_POST['user'];
	$pass=$_POST['pass'];



	$result=mysqli_query($connect,"SELECT * FROM customer WHERE user='$user'AND pass='$pass'");
	$numrows=mysqli_num_rows($result);
	if($numrows!=0)
	{
	while($row=mysqli_fetch_assoc($result))
	{

	$username=$row['user'];
	$password=$row['pass'];
	$id=$row['cust_id'];
	$fname=$row['fname'];
	if( isset($_POST['autologin']) ){
							$cookie_time = 86400 * 30;
							setcookie ('user', $user, time() + $cookie_time);
							setcookie ('pass', $pass, time() + $cookie_time);
							}
	}

	if($user == $username && $pass == $password)
	{
	session_start();
	$_SESSION['user']=$user;
	$_SESSION['id']=$id;
	$_SESSION['fname']=$fname;
	header("Location: nav.php");
	
	}
	 elseif(isset($_COOKIE['lock'])){
		setcookie('lock', $_COOKIE['lock']+1, time()+30);
	header("location:login.php");
	
	} else {
		setcookie('lock', 1, time()+30);
		header("location:login.php");
	}
}
}
	 
?>
