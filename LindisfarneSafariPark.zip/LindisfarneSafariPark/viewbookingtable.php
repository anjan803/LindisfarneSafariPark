<?php
include("nav.php");
session_start();
	$id=$_SESSION["id"];
	include_once 'connect.php';
if(!isset($_SESSION["id"])){
header("Location:login.php");
}
else
{
	?>
<html>
<head>
<title>View Booking</title>
<style type="text/css">
body {
margin:0 auto;
background-image:url("hh.jpg");
background-repeat:no-repeat;
background-size:100%;
}

</style>
<style>
.transparent{
color:white;
width: 300px;
height:250px;
 background-color: rgba(24,77,88,0.7);
 
}
.head{

width: 100%;
height:40px;
 background-color:rgba(22, 88, 49,1.7);
}


</style>
</head>
<body>
<center>
<div class="transparent">  
   <div class="head"> <h1>Booking</h1></div>
<form method="GET" action="next.php">
<table>
	Select Ticket view Booking <br> <td><select id="ticket" name="ticket" required>
   <?php
	$sql = mysqli_query($connect,"SELECT ticket_id FROM custticket WHERE cust_id='$id'") ;


while ($det = mysqli_fetch_array($sql)){
	$t_id=$det["ticket_id"]; 
	$s = mysqli_query($connect,"SELECT ticketName FROM ticket WHERE ticket_id='$t_id'");
	while ($get = mysqli_fetch_array($s)){
		$name=$get["ticketName"];
		?> <option value="<?php echo $t_id; ?>" name="t_id" required><?php echo $name; ?> </option> <?php
	}
}
}
	?>

  <input type="submit" value="Search">
  </div>
  </center>
  </form>
</html>