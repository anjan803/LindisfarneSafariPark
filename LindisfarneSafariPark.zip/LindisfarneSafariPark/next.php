<?php
include("nav.php");
session_start();
	$id=$_SESSION["id"];
	include_once 'connect.php';
if(!isset($_SESSION["id"])){
header("Location:login.php");
}
else
{?>
<html>
<head>
<style type="text/css">
   

    th,td
    {
        border: 1px solid black;
    }

   
    </style>
</head>
<body>
<center>
<h1>Booking table view</h1></center>
  <table align="center" >
    <div>
    <tr>
        <th>Time</th>
		<th>Sunday</th>
        <th>Monday</th>
        <th>Tuesday</th>
        <th>Wednesday</th>
        <th>Thrusday</th>
        <th>Friday</th>
        <th>Saturday</th>
    </tr>
</div>  

<?php
$arr=array("10:00 AM","11:00 AM","12:00 AM","01:00 PM","02:00 PM","03:00 PM","04:00 PM");
foreach($arr as $sel){
			?><th><?php echo $sel; ?></td><?php
 if(isset($_GET["ticket"])){
	$t_id=$_GET['ticket'];
	echo"<tr>";
  $a = mysqli_query($connect,"SELECT * FROM dt WHERE ticket_id='$t_id'");
	while ($met = mysqli_fetch_array($a)){
	$d_id=$met["day_id"]; 
	$time=$met["s_time"];
	$da = mysqli_query($connect,"SELECT * FROM day WHERE day_id='$d_id'");
	while ($m = mysqli_fetch_array($da)){
	$d=$m["day"];
	$b = mysqli_query($connect,"SELECT * FROM ticketservice WHERE ticket_id='$t_id' AND day_id='$d_id' AND s_time='$time'");
	while ($t = mysqli_fetch_array($b)){
	$sid=$t["service_id"]; 
	$total=$t["price"];
	$ts_id=$t["ts_id"];
	$c = mysqli_query($connect,"SELECT * FROM service WHERE service_id='$sid'");
	while ($e = mysqli_fetch_array($c)){
	$s=$e["service"];	
	
		
	}
	
	}
	
}
?>	
		<?php
		if(($d_id==5) && ($sel==$time)){?>
		<td></td>
            <td><?php
			echo "<a href=editBooking.php?ts=$ts_id>".  $s;
	?>
	</a></td>
            <td ></td>
            <td ></td>
            <td></td>
            <td ></td>
            <td ></td>
			<td ></td>
			<?php
		}
			else if(($d_id==6) && ($sel==$time)){?>
			<td  ></td>
            <td  >
			
	</td>
            <td><?php echo "<a href=editBooking.php?ts=$ts_id>".  $s
	?></a></td>
	
            <td></td>
            <td></td>
            <td></td>
            <td></td>
			<td></td>
			<?php
		}
			else if(($d_id==7) && ($sel==$time)){?>
			<td  ></td>
            <td >
			
	</td>
            <td ></td>
            <td><?php echo "<a href=editBooking.php?ts=$ts_id>".  $s;
	
	?></a></td>
            <td ></td>
            <td></td>
            <td></td>
			<td></td>
      <?php
		}
			else if(($d_id==8) && ($sel==$time)){?>
			<td></td>
            <td>
			
	</td>
            <td ></td>
            <td ></td>
            <td><?php echo "<a href=editBooking.php?ts=$ts_id>".  $s;
	?></a></td>
            <td></td>
            <td></td>
			<td></td>
        <?php
		}
			else if(($d_id==9) && ($sel==$time)){?>
			<td></td>
            <td>
			
	</td>
            <td></td>
            <td></td>
            <td></td>
            <td><?php echo "<a href=editBooking.php?ts=$ts_id>".  $s;
	?></a></td>
            <td></td>
			<td></td>
       <?php
		}
			else if(($d_id==10) && ($sel==$time)){?>
			<td></td>
            <td>
			
	</td>
            <td></td>
            <td></td>
            <td ></td>
            <td></td>
            <td><?php echo "<a href=editBooking.php?ts=$ts_id>".  $s;
	?></a></td>
	<td ></td>
        <?php
		}
			else if($d_id==11 && $sel==$time){?>
			<td></td>
            <td>
			
	</td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
			<td><?php echo"<a href=editBooking.php?ts=$ts_id>". $s;?>
			
			</a></td><?php } echo"<tr>"; ?>
        

<?php
	}
	
}
	}
}
?>
</table>
<hr>
Click on the cell to edit.
</body>
</html>