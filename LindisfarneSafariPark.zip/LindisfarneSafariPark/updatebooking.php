 <?php
 include "nav.php";
 include "connect.php";
   $p=$_POST['ts'];
  $s=$_POST['service'];
  $ticket=$_POST['ticket'];
  $day=$_POST['day'];
  $t=$_POST['d'];
 if(isset($_POST["sub"])){

 $sql_query="Update ticketservice set service_id='$s' where ts_id='$p'";
	
	mysqli_query($connect,$sql_query) or die ('Error');
	header("location:viewbookingtable.php");

 }
?>