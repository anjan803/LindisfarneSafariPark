<!doctype html>
<html>
<head>
<title>ADD Ticket</title>
<style>

.transparent{
color:white;
width: 300px;
height:220px;
 background-color: rgba(22,77,11,0.7);
 
}
.head{

width: 100%;
height:40px;
 background-color:rgba(11, 77, 49,0.7);
}


body {
margin:0 auto;
background-image:url("aa.jpg");
background-repeat:no-repeat;
background-size:100%;
}



</style>
<?php
include ("nav.php");
?>

</head>
<body>

<center>

<div class="transparent" id="div">
<div class="head"> <h3> Add Ticket</h3></div>
<form action="addticketsql.php" method="POST" id="myform">
<table>
<tr><td>Tikect Name/No</td> </tr><tr><td> <input type="text" name="addticket"></td></tr>

<tr><td><input type="submit" value="Add" name="add1" /></td></tr>

</table>
</form>
</div>
</center>
</body>
</html>
