
<!DOCTYPE html>
<html>
<head>

<style>
ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}

li {
    float: left;
}

li a {
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

li a:hover {
    background-color: #888;
}

li a.active {
    background-color: #888;
    color: white;
}

li a, .dropbtn {
    display: inline-block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

li a:hover, .dropdown:hover .dropbtn {
    background-color: #888;
}

li.dropdown {
    display: inline-block;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #888;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
}

.dropdown-content a {
    color: white;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    text-align: left;
}

.dropdown-content a:hover {background-color: #333}

.dropdown:hover .dropdown-content {
    display: block;
}

li {
    border-left: 1px solid #bbb;
}
</style>
</head>
<body>
<div style="width:100%">
<ul>


<li style="float:right" class="dropdown">
    <a href="#" class="dropbtn">Profile</a>
    <div class="dropdown-content">
    <a href="logout.php">Logout</a>
    </div>
  </li>

  <li style="float:right" class="dropdown">
    <a href="#" class="dropbtn">Ticket Management</a>
    <div class="dropdown-content">
      <a href="Ticketadding.php">Add Ticket</a>
      <a href="updateTicket.php">Edit Ticket</a>
    </div>
  </li>
  
  <li style="float:right" class="dropdown"><a class="" href="">Ticket Booking Service</a>
  <div class="dropdown-content">
      <a href="Booking.php">Book Services</a>
	  <a href="viewbookingtable.php">View Booking Table</a>
      <a href="VIPBooking.php">VIP Booking</a>
      <a href="send_mail.php">Send Mail</a>

	  </div>
  </li>
    <li style="float:right" class="dropdown">
        <a href="#" class="dropbtn">Shedule</a>
        <div class="dropdown-content">
            <a href="shedule.php">View shedule</a>

        </div>
    </li>

  <li style="float:right" class="dropdown"><a class="" href="">Total Costs Calculation</a>
  <div class="dropdown-content">
  <a href="cost.php">View Cost</a>
	  
	  </div>
  </li>

</ul>
</div>
</body>
</html>



