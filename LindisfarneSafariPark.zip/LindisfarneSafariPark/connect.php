<?php
$host="localhost";
$user="root";
$password="";
$database="safaripark";

$connect=mysqli_connect($host,$user,$password) or die ("Could not connect");
mysqli_select_db($connect,"safaripark");



?>