<?php

session_start();
?>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="../css/style.css">
    <title>Shedule</title>

    <style>
        td {
            height: 100px;
            width: 100px;
            text-align: center;
            font-size: 20px;
        }

        table {
            border-collapse: collapse;
            width: 100%;
            border-radius: 10px;
        }

    </style>

</head>
<body>
<div class="header">
    <div class="logo">

        <?php
        include ("nav.php");
        ?>
        <center><h1>Lindisfarne Safari Park</h1></center>


<div class="content">
    <div style="background: red; width: 80%; margin: auto; overflow-x:auto;">
        <table border="-20" style="color: white;">
            <tr>
                <td style="background: blue;">Days & month</td>
                <td style="background: blue;">Sunday</td>
                <td style="background: blue;">Monday</td>
                <td style="background: blue;">Tuesday</td>
                <td style="background: blue;">Wednesday</td>
                <td style="background: blue;">Thursday</td>
                <td style="background: blue;">Friday</td>
                <td style="background: blue;">Saturday</td>
            </tr>
            <tr>
                <td style="background: blue;">January</td>
                <td>10:00 AM - 04:00 PM</td>
                <td>11:00 AM - 03:00 PM</td>
                <td>10:00 AM - 04:00 PM</td>
                <td style="background:yellow">10:00 to 11:00 only open</td>
                <td>10:00 AM - 04:00 PM</td>
                <td>12:00 AM - 03:00 PM</td>
                <td>10:00 AM - 04:00 PM</td>
            </tr>
            <tr>
                <td style="background: blue;">February</td>
                <td>10:00 AM - 04:00 PM</td>
                <td>11:00 AM - 03:00 PM</td>
                <td>10:00 AM - 04:00 PM<br><p style="font-size: 13px; color: black;">(Special Offer Available)</p></td>
                <td style="background: yellow;">10:00 to 11:00 only open</td>
                <td>10:00 AM - 04:00 PM</td>
                <td>12:00 AM - 03:00 PM</td>
                <td>10:00 AM - 04:00 PM</td>
            </tr>
            <tr>
                <td style="background:blue;">March</td>
                <td>10:00 AM - 04:00 PM</td>
                <td>11:00 AM - 03:00 PM</td>
                <td>10:00 AM - 04:00 PM</td>
                <td style="background: yellow;">10:00 to 11:00 only open</td>
                <td>10:00 AM - 04:00 PM</td>
                <td>12:00 AM - 03:00 PM</td>
                <td>10:00 AM - 04:00 PM</td>
            </tr>
            <tr>
                <td style="background: blue;">April</td>
                <td>10:00 AM - 04:00 PM</td>
                <td>11:00 AM - 03:00 PM</td>
                <td>10:00 AM - 04:00 PM</td>
                <td style="background: yellow;">10:00 to 11:00 only open</td>
                <td>10:00 AM - 04:00 PM<br><p style="font-size: 13px; color: black;">(Special Offer Available)</p></td>
                <td>12:00 AM - 03:00 PM</td>
                <td>10:00 AM - 04:00 PM</td>
            </tr>
            <tr>
                <td style="background: blue">May</td>
                <td>10:00 AM - 04:00 PM</td>
                <td>11:00 AM - 03:00 PM</td>
                <td>10:00 AM - 04:00 PM</td>
                <td style="background: yellow;">10:00 to 11:00 only open</td>
                <td>10:00 AM - 04:00 PM</td>
                <td>12:00 AM - 03:00 PM</td>
                <td>10:00 AM - 04:00 PM</td>
            </tr>
            <tr>
                <td style="background: blue;">June</td>
                <td>10:00 AM - 04:00 PM</td>
                <td>11:00 AM - 03:00 PM</td>
                <td>10:00 AM - 04:00 PM</td>
                <td style="background: yellow;">10:00 to 11:00 only open</td>
                <td>10:00 AM - 04:00 PM</td>
                <td>12:00 AM - 03:00 PM</td>
                <td>10:00 AM - 04:00 PM<br><p style="font-size: 13px; color: black;">(Special Offer Available)</p></td>
            </tr>
            <tr>
                <td style="background: blue;">July</td>
                <td>10:00 AM - 04:00 PM</td>
                <td>11:00 AM - 03:00 PM</td>
                <td>10:00 AM - 04:00 PM</td>
                <td style="background: yellow;">10:00 to 11:00 only open</td>
                <td>10:00 AM - 04:00 PM</td>
                <td>12:00 AM - 03:00 PM</td>
                <td>10:00 AM - 04:00 PM</td>
            </tr>
            <tr>
                <td style="background: blue;">August</td>
                <td>10:00 AM - 04:00 PM<br><p style="font-size: 13px; color: black;">(Special Offer Available)</p></td>
                <td>11:00 AM - 03:00 PM</td>
                <td>10:00 AM - 04:00 PM</td>
                <td style="background: yellow;">10:00 to 11:00 only open</td>
                <td>10:00 AM - 04:00 PM</td>
                <td>12:00 AM - 03:00 PM</td>
                <td>10:00 AM - 04:00 PM</td>
            </tr>
            <tr>
                <td style="background: blue;">September</td>
                <td>10:00 AM - 04:00 PM</td>
                <td>11:00 AM - 03:00 PM</td>
                <td>10:00 AM - 04:00 PM</td>
                <td style="background:yellow;">10:00 to 11:00 only open</td>
                <td>10:00 AM - 04:00 PM</td>
                <td>12:00 AM - 03:00 PM</td>
                <td>10:00 AM - 04:00 PM</td>
            </tr>
            <tr>
                <td style="background: blue;">October</td>
                <td>10:00 AM - 04:00 PM</td>
                <td>11:00 AM - 03:00 PM<br><p style="font-size: 13px; color: black;">(Special Offer Available)</p></td>
                <td>10:00 AM - 04:00 PM</td>
                <td style="background: yellow;">10:00 to 11:00 only open</td>
                <td>10:00 AM - 04:00 PM</td>
                <td>12:00 AM - 03:00 PM</td>
                <td>10:00 AM - 04:00 PM</td>
            </tr>
            <tr>
                <td style="background: blue;">November</td>
                <td>10:00 AM - 04:00 PM</td>
                <td>11:00 AM - 03:00 PM</td>
                <td>10:00 AM - 04:00 PM</td>
                <td style="background: yellow;">10:00 to 11:00 only open</td>
                <td>10:00 AM - 04:00 PM</td>
                <td>12:00 AM - 03:00 PM</td>
                <td>10:00 AM - 04:00 PM</td>
            </tr>
            <tr>
                <td style="background: blue;">December</td>
                <td>10:00 AM - 04:00 PM</td>
                <td>11:00 AM - 03:00 PM</td>
                <td>10:00 AM - 04:00 PM</td>
                <td style="background: yellow;">10:00 to 11:00 only open</td>
                <td>10:00 AM - 04:00 PM</td>
                <td>12:00 AM - 03:00 PM<br><p style="font-size: 13px; color: black;">(Special Offer Available)</p></td>
                <td>10:00 AM - 04:00 PM</td>
            </tr>
        </table>
    </div>
</div>
</body>
</html>


